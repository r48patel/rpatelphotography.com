from __future__ import print_function

import json
import urllib
import boto3
import os
from base64 import b64decode
from  db import *

print('Loading function')

s3 = boto3.client('s3')

def main():
    if 'DATABASE_URL' not in os.environ:
        raise Exception('DATABASE_URL not defined as env variable')

    if 'USER' in os.environ:
        session = boto3.Session(profile_name='personal')
        kms = session.client('kms')
    else:
        kms = boto3.client('kms')

    ENCRYPTED_DATABASE_URL = os.environ['DATABASE_URL']
    # Decrypt code should run once and variables stored outside of the function
    # handler so that these are decrypted once per container
    DATABASE_URL = kms.decrypt(CiphertextBlob=b64decode(ENCRYPTED_DATABASE_URL))['Plaintext']

    psql = PSQL(DATABASE_URL)

    test=psql.select("*", "role")
    print (test)


def lambda_handler(event, context):
    #print("Received event: " + json.dumps(event, indent=2))

    # Get the object from the event and show its content type
    bucket = event['Records'][0]['s3']['bucket']['name']
    key = urllib.unquote_plus(event['Records'][0]['s3']['object']['key'].encode('utf8'))
    print ("bucket: " + bucket)
    print ("key: " + key)
    try:
        response = s3.get_object(Bucket=bucket, Key=key)
        print("CONTENT TYPE: " + response['ContentType'])
        if response['ContentType'] == "image/jpeg":
            print("Uploading S3 object")
            s3.put_object(Bucket=bucket,
                  Key=key+"-lambda.log",
                  Body=b'processed')

        main()
        return response['ContentType']
    except Exception as e:
        print(e)
        print('Error getting object {} from bucket {}. Make sure they exist and your bucket is in the same region as this function.'.format(key, bucket))
        raise e
        

if __name__ == '__main__':
    main()